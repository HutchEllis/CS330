///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// Manage the preparation and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including shader settings, materials, and lighting.
 ***********************************************************/
class SceneManager
{
public:
    // Constructor
    SceneManager(ShaderManager* pShaderManager);

    // Destructor
    ~SceneManager();

    // Properties for loaded texture access
    struct TEXTURE_INFO
    {
        std::string tag;
        uint32_t ID;
    };

    // Properties for object materials
    struct OBJECT_MATERIAL
    {
        glm::vec3 ambientColor;
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    // Pointer to shader manager object
    ShaderManager* m_pShaderManager;

    // Pointer to basic shapes object
    ShapeMeshes* m_basicMeshes;

    // Total number of loaded textures
    int m_loadedTextures;

    // Loaded textures info
    TEXTURE_INFO m_textureIDs[16];

    // Collection of defined materials
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // Load texture images and convert to OpenGL texture data
    bool CreateGLTexture(const char* filename, std::string tag);

    // Bind loaded OpenGL textures to slots in memory
    void BindGLTextures();

    // Free the loaded OpenGL textures
    void DestroyGLTextures();

    // Find a loaded texture by tag
    int FindTextureID(std::string tag);

    // Find a slot index for the previously loaded texture
    int FindTextureSlot(std::string tag);

    // Find a defined material by tag
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Set the transformation values into the transform buffer
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    // Set the color values into the shader
    void SetShaderColor(
        float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);

    // Set the texture data into the shader
    void SetShaderTexture(
        std::string textureTag);

    // Set the UV scale for the texture mapping
    void SetTextureUVScale(
        float u, float v);

    // Set the object material into the shader
    void SetShaderMaterial(
        std::string materialTag);

    // Load textures for the 3D scene
    void LoadSceneTextures();

    // Define object materials
    void DefineObjectMaterials();

    // Setup lights for the scene
    void SetupSceneLights();

public:
    // Methods for students to customize their own 3D scene
    void PrepareScene();
    void RenderScene();
};
